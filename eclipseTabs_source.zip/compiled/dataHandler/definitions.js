export const updateHTMLEvent = new Event('updateHTMLList');
export const pinnedIndex = 0;
export const pinnedFolderID = "pinned";
export const unorderedIndex = Number.MAX_SAFE_INTEGER;
export const unorderedFolderID = "unordered";
//# sourceMappingURL=definitions.js.map
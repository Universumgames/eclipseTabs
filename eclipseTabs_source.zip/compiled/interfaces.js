export var Mode;
(function (Mode) {
    Mode[Mode["Default"] = 0] = "Default";
    Mode[Mode["Move"] = 1] = "Move";
})(Mode || (Mode = {}));
//# sourceMappingURL=interfaces.js.map
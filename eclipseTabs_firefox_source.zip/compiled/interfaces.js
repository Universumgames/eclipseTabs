export var Mode;
(function (Mode) {
    Mode[Mode["Default"] = 0] = "Default";
    Mode[Mode["Move"] = 1] = "Move";
})(Mode || (Mode = {}));
export var ColorScheme;
(function (ColorScheme) {
    ColorScheme[ColorScheme["dark"] = 0] = "dark";
    ColorScheme[ColorScheme["light"] = 1] = "light";
})(ColorScheme || (ColorScheme = {}));
//# sourceMappingURL=interfaces.js.map
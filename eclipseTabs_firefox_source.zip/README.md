# eclipseTab

This is browser extension for firefox (in the future more browsers will be supported). 
The extension is designed to organize your hundrets of tabs into folders and subfolders. Using it with Firefox you are even capable of hidin tabs from your normal tab view. If all current and future features will be available with other browsers cannot be guaranteed. 
<br/>
#### Disclaimer 
##### The development is primarily focused on improving the extension for Firefox, because that's the browser I primarily use...
<br/>
<br/>

## Installation

Currently the "installation" process is extremely simple but as simple at it is the short lived it is as well. After each restart of your browser you have to "reinstall" it again, but thhis is only during the development process. In the future it will be easily downloaded and installed through the extension store within your modern web browser.
The only way to install this extension at the moment is either to zip all important files into one folder called ```"eclipseTab.zip"```. Within the folder should be the  ```compiled``` directory where all Javascript files are located, the ```manifest.json``` as well as the ```icons``` directory. To install the extension in Firefox, enable the developer mode within the browser settings and install the extension as a temporary addon either by using the zipped folder or by using the ```manifest.json```.